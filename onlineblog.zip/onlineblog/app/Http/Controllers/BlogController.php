<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class BlogController extends Controller
{
    public function login(Request $request)
    {
    $credentials = $request->only('email', 'password');

    if (Auth::attempt($credentials)) {
        $request->session()->regenerate();

        // Redirect based on role
        if (Auth::user()->role === 'ADMIN') {
            return redirect()->route('blogs.index')->with('success', 'Welcome Admin!');
        } else {
            return redirect()->route('blogs.index')->with('success', 'Logged in successfully!');
        }
    }

    return back()->withErrors([
        'email' => 'The provided credentials do not match our records.',
    ])->onlyInput('email');
    }

    // Show all blogs (public view)
    public function index()
    {
        // Admin sees all blogs, regular users see only approved blogs
        if (Auth::check() && Auth::user()->role === 'ADMIN') {
            $blogs = Blog::with('user')->latest()->paginate(10);
        } else if (Auth::check() && Auth::user()->role === 'USER') {
            $blogs = Blog::with('user')
                ->latest()
                ->paginate(10);
        } else{
             $blogs = Blog::with('user')
                ->where('status','approved')
                ->latest()
                ->paginate(10);
        }
        
        return view('blogs.index', compact('blogs'));
    }
    // Show user's own blogs
    public function myBlogs()
    {
        $blogs = Blog::where('user_id', Auth::id())
            ->latest()
            ->get();
        
        return view('blogs.my-blogs', compact('blogs'));
    }

    // Show single blog
    public function show($id)
    {
        $blog = Blog::with('user')->findOrFail($id);
        
        // Admin can view any blog, users can view approved blogs or their own
        if (Auth::check() && Auth::user()->role === 'ADMIN') {
            return view('blogs.show', compact('blog'));
        }
        
        if ($blog->status !== 'approved' && $blog->user_id !== Auth::id()) {
            abort(403, 'Unauthorized access');
        }
        
        return view('blogs.show', compact('blog'));
    }

    // Show create form (only for authenticated users)
    public function create()
    {
        return view('blogs.create');
    }

    // Store new blog (only for regular users)
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|max:255',
            'content' => 'required',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $blog = new Blog();
        $blog->title = $validated['title'];
        $blog->content = $validated['content'];
        $blog->user_id = Auth::id();
        $blog->status = 'pending'; // Default status

        // Handle image upload
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads'), $imageName);
            $blog->image = $imageName;
        }

        $blog->save();

        return redirect()->route('blogs.index')
            ->with('success', 'Blog created successfully! Waiting for approval.');
    }

    // Show edit form
    public function edit($id)
    {
        $blog = Blog::findOrFail($id);
        
        // Check if user owns this blog and can edit it
        if ($blog->user_id !== Auth::id()) {
            abort(403, 'Unauthorized access');
        }
        
        if (!in_array($blog->status, ['pending', 'rejected'])) {
            return redirect()->route('blogs.my-blogs')
                ->with('error', 'You can only edit pending or rejected blogs.');
        }
        
        return view('blogs.edit', compact('blog'));
    }

    // Update blog
    public function update(Request $request, $id)
    {
        $blog = Blog::findOrFail($id);
        
        // Check authorization
        if ($blog->user_id !== Auth::id()) {
            abort(403, 'Unauthorized access');
        }
        
        if (!in_array($blog->status, ['pending', 'rejected'])) {
            return redirect()->route('blogs.my-blogs')
                ->with('error', 'You can only edit pending or rejected blogs.');
        }

        $validated = $request->validate([
            'title' => 'required|max:255',
            'content' => 'required',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);

        $blog->title = $validated['title'];
        $blog->content = $validated['content'];
        $blog->status = 'pending'; // Reset to pending after edit

        // Handle new image upload
        if ($request->hasFile('image')) {
            // Delete old image if exists
            if ($blog->image && file_exists(public_path('uploads/' . $blog->image))) {
                unlink(public_path('uploads/' . $blog->image));
            }
            
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $image->move(public_path('uploads'), $imageName);
            $blog->image = $imageName;
        }

        $blog->save();

        return redirect()->route('blogs.my-blogs')
            ->with('success', 'Blog updated successfully!');
    }

    // Delete blog
    public function destroy(Blog $blog)
    {
        // Admin can delete any blog, users can only delete their own pending/rejected blogs
        if (Auth::user()->role === 'ADMIN') {
            // Admin can delete any blog
            if ($blog->image && file_exists(public_path('uploads/' . $blog->image))) {
                unlink(public_path('uploads/' . $blog->image));
            }
            
            $blog->delete();
            
            return redirect()->back()
                ->with('success', 'Blog deleted successfully!');
        }
        
        // Regular user deletion logic
        if ($blog->user_id !== Auth::id()) {
            abort(403, 'Unauthorized action.');
        }

        // Check if blog can be deleted
        if (!in_array($blog->status, ['pending', 'rejected'])) {
            return redirect()->route('blogs.my-blogs')
                ->with('error', 'You can only delete pending or rejected blogs.');
        }

        // Delete image if exists
        if ($blog->image && file_exists(public_path('uploads/' . $blog->image))) {
            unlink(public_path('uploads/' . $blog->image));
        }
        
        $blog->delete();

        return redirect()->route('blogs.index')
            ->with('success', 'Blog deleted successfully!');
    }

    // Show all blogs for ADMIN dashboard
    public function adminBlogs()
    {
        // Only ADMIN can access
        if (Auth::user()->role !== 'ADMIN') {
            abort(403, 'Unauthorized access');
        }
        
        $blogs = Blog::with('user')->latest()->paginate(15);
        return view('blogs.admin', compact('blogs'));
    }

  public function updateStatus(Request $request, Blog $blog)
        {
            $request->validate([
                'status' => 'required|in:approved,rejected,pending',
            ]);

            $blog->status = $request->status;
            $blog->save();

            return response()->json([
                'success' => true,
                'status' => $blog->status
            ]);
        }

    public function logout()
    {
        Auth::logout();                // Log out the user
        request()->session()->invalidate(); // Invalidate the session
        request()->session()->regenerateToken(); // Regenerate CSRF token

        return redirect()->route('login.form')->with('success', 'Logged out successfully!');
    }
}