<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\UserController;

// ===== Home =====
Route::get('/', function () {
    if (auth()->check()) {
        if (auth()->user()->user_type === 'ADMIN') {
            return redirect()->route('admin.blogs'); // Admin dashboard
        } else {
            return redirect()->route('blogs.my-blogs'); // USER page
        }
    }
    return redirect()->route('login.form'); // Guest
});

// ===== Auth Routes =====
Route::get('/register', [AuthController::class, 'showRegisterForm'])->name('register.form');
Route::post('/register', [AuthController::class, 'register'])->name('register');
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login.form');
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// ===== Public Blog Routes =====
Route::get('/blogs', [BlogController::class, 'index'])->name('blogs.index');
Route::get('/blogs/{blog}', [BlogController::class, 'show'])->name('blogs.show');
Route::get('/create-blog', function () {
    return view('blogs.create');
})->name('create-blog');
// ===== Authenticated Users =====
Route::middleware(['auth'])->group(function () {

    // User routes
    Route::get('/blogs/my-blogs', [BlogController::class, 'myBlogs'])->name('blogs.my-blogs');
    // Route::get('/blogs/create', [BlogController::class, 'create'])->name('blogs.create');
    Route::get('/blogs/create', [BlogController::class, 'create'])->name('blogs.create');

    Route::post('/blogs', [BlogController::class, 'store'])->name('blogs.store');
    Route::get('/blogs/{blog}/edit', [BlogController::class, 'edit'])->name('blogs.edit');
    Route::put('/blogs/{blog}', [BlogController::class, 'update'])->name('blogs.update');
    Route::delete('/blogs/{blog}', [BlogController::class, 'destroy'])->name('blogs.destroy');
    // Admin routes
    Route::middleware(['admin'])->group(function () {
        Route::get('/admin/blogs', [BlogController::class, 'adminBlogs'])->name('admin.blogs');
        Route::post('/blogs/{blog}/status', [BlogController::class, 'updateStatus'])->name('blogs.updateStatus');
Route::post('/blogs/{blog}/status', [BlogController::class, 'updateStatus'])->name('blogs.updateStatus');

        // Users list (ADMIN only)
        Route::get('/users', [UserController::class, 'index'])->name('users.index');
    });

Route::post('/blogs/{blog}/status', [BlogController::class, 'updateStatus'])
    ->name('blogs.updateStatus')
    ->middleware('auth'); // only authenticated users (admins)

});
