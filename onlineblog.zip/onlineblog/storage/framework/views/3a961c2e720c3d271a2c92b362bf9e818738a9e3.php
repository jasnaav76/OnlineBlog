
<?php use Illuminate\Support\Facades\Auth;

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Management - Admin Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #667eea;
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
            font-size: 1.1em;
        }

        .actions {
            display: flex;
            gap: 15px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .btn {
            padding: 12px 25px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            font-weight: 600;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }

        .btn-secondary {
            background: white;
            color: #667eea;
        }

        .btn-secondary:hover {
            background: #f0f0f0;
            transform: translateY(-2px);
        }

        .btn-success {
            background: #48bb78;
            color: white;
            font-size: 14px;
            padding: 8px 16px;
        }

        .btn-success:hover {
            background: #38a169;
        }

        .btn-danger {
            background: #f56565;
            color: white;
            font-size: 14px;
            padding: 8px 16px;
        }

        .btn-danger:hover {
            background: #e53e3e;
        }

        .card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            overflow: hidden;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }

        thead th {
            padding: 20px;
            text-align: left;
            color: white;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.3s ease;
        }

        tbody tr:hover {
            background: #f8f9ff;
            transform: scale(1.01);
        }

        tbody td {
            padding: 20px;
            color: #333;
        }

        .blog-title {
            font-weight: 600;
            color: #667eea;
            font-size: 16px;
        }

        .blog-excerpt {
            color: #666;
            font-size: 14px;
            margin-top: 5px;
            line-height: 1.5;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border-left: 4px solid #48bb78;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state svg {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .empty-state h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #666;
        }

        .empty-state p {
            font-size: 16px;
            margin-bottom: 20px;
        }

        @media (max-width: 768px) {
            .header h1 {
                font-size: 1.8em;
            }

            .actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }

            table {
                font-size: 14px;
            }

            thead th, tbody td {
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📝 Blog Management</h1>
            <p>Manage all your blog posts from one place</p>
        </div>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                ✓ <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

       <?php if(auth()->guard()->check()): ?>
            <?php if(Auth::user()->role === 'USER'): ?>
                <a href="<?php echo e(route('create-blog')); ?>" class="btn btn-primary">
                    + Create New Blog
                </a>
            <?php endif; ?>
        <?php endif; ?>
        <?php if(Auth::check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Logout</button>
            </form>
        <?php endif; ?>

        <div class="card">
            <div class="table-container">
                <?php if(isset($blogs) && $blogs->count() > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title & Excerpt</th>
                                 <th>Image</th>
                                <th>Author</th>
                                <th>Status</th>
                                <th>Created</th>
                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->role === 'ADMIN'): ?>
                                        <th>Actions</th>
                                    <?php endif; ?>
                                <?php endif; ?>
                                 <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->role === 'USER'): ?>
                                        <th>Delete</th>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong>#<?php echo e($blog->id); ?></strong></td>
                                    <td>
                                        <div class="blog-title"><?php echo e($blog->title); ?></div>
                                        <div class="blog-excerpt">
                                            <?php echo e(Str::limit($blog->content ?? 'No content', 80)); ?>

                                        </div>
                                    </td>
                                   <td>
                                        <?php if($blog->image): ?>
                                            <img src="<?php echo e(asset('uploads/' . $blog->image)); ?>" alt="Blog Image" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px;">
                                        <?php else: ?>
                                            No Image
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($blog->user->name ?? 'Unknown'); ?></td>
                                    <td>
                                         <span style="padding: 5px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; 
                                            background: <?php echo e($blog->status == 'published' ? '#c6f6d5' : '#feebc8'); ?>; 
                                            color: <?php echo e($blog->status == 'published' ? '#22543d' : '#7c2d12'); ?>;">
                                            <?php echo e(ucfirst($blog->status ?? 'draft')); ?>

                                        </span> 
                                    </td>
                                    <td><?php echo e($blog->created_at->format('M d, Y')); ?></td>
                                    <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->role === 'ADMIN'): ?> <td>
                                        <div class="action-buttons">
                                            <form class="status-form" data-id="<?php echo e($blog->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <select name="status" class="status-select">
                                                    <option value="approved" <?php echo e($blog->status == 'approved' ? 'selected' : ''); ?>>Published</option>
                                                    <option value="rejected" <?php echo e($blog->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                                    <option value="pending" <?php echo e($blog->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                                </select>
                                            </form>
                                            
                                        </div>
                                    </td>
                                     <?php endif; ?>
                                <?php endif; ?>
                               
                                    <?php if(auth()->guard()->check()): ?>
                                    <?php if(Auth::user()->role === 'USER'): ?> <td>
                                        <div class="action-buttons">
                                           <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>" method="POST" style="display: inline;" 
                                                  onsubmit="return confirm('Are you sure you want to delete this blog?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    🗑️ Delete
                                                </button>
                                            </form>
                                            
                                        </div>
                                    </td>
                                     <?php endif; ?>
                                <?php endif; ?>
                                
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="empty-state">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        <h3>No Blogs Found</h3>
                        <p>Start creating amazing content by adding your first blog post!</p>
                        <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-primary">
                            ➕ Create Your First Blog
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if(isset($blogs) && $blogs->hasPages()): ?>
            <div style="margin-top: 30px; display: flex; justify-content: center;">
                <?php echo e($blogs->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</body>
</html>
<script>
document.querySelectorAll('.status-select').forEach(function(select) {
    select.addEventListener('change', function() {
        let form = this.closest('.status-form');
        let blogId = form.dataset.id;
        let status = this.value;

      fetch(`/blogs/${blogId}/status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            body: JSON.stringify({ status: status })
        })

        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Status updated to ' + data.status);
            } else {
                alert(data.message || 'Something went wrong!');
            }
        })
        .catch(err => {
            console.error(err);
            alert('AJAX request failed. Check console.');
        });
    });
});
</script>
<?php /**PATH C:\xampp\htdocs\onlineblog\resources\views/blogs/index.blade.php ENDPATH**/ ?>