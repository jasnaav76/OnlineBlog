<!DOCTYPE html>
<html>
<head>
    <title>My Blogs</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header h1 {
            margin: 0 0 10px 0;
            color: #333;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-right: 10px;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn-danger {
            background: #dc3545;
        }
        .btn-danger:hover {
            background: #c82333;
        }
        .btn-success {
            background: #28a745;
        }
        .btn-success:hover {
            background: #218838;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #c3e6cb;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border: 1px solid #f5c6cb;
        }
        .blog-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .blog-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }
        .blog-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        .blog-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #e9ecef;
        }
        .blog-content {
            padding: 15px;
        }
        .blog-title {
            font-size: 18px;
            font-weight: bold;
            margin: 0 0 10px 0;
            color: #333;
        }
        .blog-excerpt {
            color: #666;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 10px;
        }
        .blog-meta {
            font-size: 12px;
            color: #999;
            margin-bottom: 15px;
        }
        .status-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .blog-actions {
            display: flex;
            gap: 10px;
        }
        .blog-actions .btn {
            flex: 1;
            text-align: center;
            padding: 8px 12px;
            font-size: 13px;
            margin: 0;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 8px;
            color: #666;
        }
        .empty-state h2 {
            color: #999;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>My Blogs</h1>
        <p>Welcome, <?php echo e(Auth::user()->name); ?></p>
        <a href="<?php echo e(route('blogs.create')); ?>" class="btn btn-success">+ Create New Blog</a>
        <!-- <a href="<?php echo e(route('blogs.index')); ?>" class="btn">View All Blogs</a> -->
        <?php if(Auth::check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Logout</button>
            </form>
        <?php endif; ?>
    </div>


    <?php if(session('success')): ?>
        <div class="success-message">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="error-message">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($blogs->count() > 0): ?>
        <div class="blog-grid">
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="blog-card">
                    <?php if($blog->image): ?>
                        <img src="<?php echo e(asset('uploads/'.$blog->image)); ?>" class="blog-image" alt="<?php echo e($blog->title); ?>">
                    <?php else: ?>
                        <div class="blog-image"></div>
                    <?php endif; ?>
                    
                    <div class="blog-content">
                        <span class="status-badge status-<?php echo e(strtolower($blog->status)); ?>">
                            <?php echo e(ucfirst($blog->status)); ?>

                        </span>
                        
                        <h3 class="blog-title"><?php echo e($blog->title); ?></h3>
                        
                        <p class="blog-excerpt">
                            <?php echo e(Str::limit($blog->content, 100)); ?>

                        </p>
                        
                        <p class="blog-meta">
                            Created: <?php echo e($blog->created_at->format('M d, Y')); ?>

                        </p>

                        <div class="blog-actions">
                            <a href="<?php echo e(route('blogs.show', $blog->id)); ?>" class="btn">Delete</a>
                            
                            <?php if($blog->status === 'pending' || $blog->status === 'rejected'): ?>
                                <!-- <a href="<?php echo e(route('blogs.edit', $blog->id)); ?>" class="btn">Edit</a> -->
                                
                                <form action="<?php echo e(route('blogs.destroy', $blog->id)); ?>" method="POST" 
                                      onsubmit="return confirm('Are you sure you want to delete this blog?');"
                                      style="margin: 0; flex: 1;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger" style="width: 100%;">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="empty-state">
            <h2>No Blogs Yet</h2>
            <p>You haven't created any blogs yet. Click the button above to create your first blog!</p>
        </div>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\onlineblog\resources\views/blogs/my-blogs.blade.php ENDPATH**/ ?>