<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($blog->title); ?></title>
</head>
<body>
    <h1><?php echo e($blog->title); ?></h1>
    <p>By: <?php echo e($blog->user->name); ?> (<?php echo e($blog->user->role); ?>)</p>
    <?php if($blog->image): ?>
        <img src="<?php echo e(asset('uploads/'.$blog->image)); ?>" width="300"><br><br>
    <?php endif; ?>
    <p><?php echo e($blog->content); ?></p>

    <br>
    <a href="<?php echo e(route('blogs.index')); ?>">Back to Blogs</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\onlineblog\resources\views/blogs/show.blade.php ENDPATH**/ ?>