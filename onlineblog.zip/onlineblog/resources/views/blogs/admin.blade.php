@extends('layouts.app')

@section('content')
<h1>All Users Blogs (Admin)</h1>

<table border="1" cellpadding="10">
    <thead>
        <tr>
            <th>Title</th>
            <th>User</th>
            <th>Status</th>
            <th>Change Status</th>
        </tr>
    </thead>
    <tbody>
        @foreach($blogs as $blog)
        <tr id="blog-{{ $blog->id }}">
            <td>{{ $blog->title }}</td>
            <td>{{ $blog->user->name }}</td>
            <td class="status">{{ $blog->status }}</td>
            <td>
                <select class="change-status" data-id="{{ $blog->id }}">
                    <option value="pending" {{ $blog->status=='pending' ? 'selected' : '' }}>Pending</option>
                    <option value="approved" {{ $blog->status=='approved' ? 'selected' : '' }}>Approved</option>
                    <option value="rejected" {{ $blog->status=='rejected' ? 'selected' : '' }}>Rejected</option>
                </select>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function(){
    $('.change-status').change(function(){
        var blogId = $(this).data('id');
        var status = $(this).val();
        $.ajax({
            url: '/blogs/' + blogId + '/status',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                status: status
            },
            success: function(response){
                if(response.success){
                    $('#blog-' + blogId + ' .status').text(response.status);
                    alert('Status updated to ' + response.status);
                }
            }
        });
    });
});
</script>
@endsection
