<!DOCTYPE html>
<html>
<head>
    <title>Create Blog</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .btn-logout {
            background: #dc3545;
            color: white;
            padding: 8px 16px;
            font-size: 13px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn-logout:hover {
            background: #c82333;
        }
        .error-box {
            background: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .error-box ul {
            margin-left: 20px;
        }
        .error-box li {
            margin: 5px 0;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            font-weight: bold;
            color: #333;
            margin-bottom: 8px;
            font-size: 14px;
        }
        input[type="text"],
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
            font-family: Arial, sans-serif;
            transition: border-color 0.3s;
        }
        input[type="text"]:focus,
        textarea:focus {
            outline: none;
            border-color: #007bff;
        }
        textarea {
            min-height: 200px;
            resize: vertical;
        }
        input[type="file"] {
            padding: 10px 0;
            font-size: 14px;
        }
        .file-info {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }
        button, .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background 0.3s;
        }
        button[type="submit"] {
            background: #28a745;
            color: white;
            font-weight: bold;
        }
        button[type="submit"]:hover {
            background: #218838;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn-secondary:hover {
            background: #5a6268;
        }
        .image-preview {
            margin-top: 10px;
            max-width: 200px;
            display: none;
        }
        .image-preview img {
            width: 100%;
            border-radius: 5px;
            border: 2px solid #ddd;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Create New Blog</h1>
        <p class="subtitle">Share your thoughts with the community</p>

        @if ($errors->any())
            <div class="error-box">
                <strong>Please fix the following errors:</strong>
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('blogs.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            
            <div class="form-group">
                <label>Blog Title *</label>
                <input type="text" name="title" value="{{ old('title') }}" 
                       placeholder="Enter an engaging title for your blog" required>
            </div>

            <div class="form-group">
                <label>Content *</label>
                <textarea name="content" placeholder="Write your blog content here..." required>{{ old('content') }}</textarea>
            </div>

            <div class="form-group">
                <label>Featured Image</label>
                <input type="file" name="image" id="imageInput" accept="image/*" onchange="previewImage(event)">
                <p class="file-info">Supported formats: JPG, PNG, GIF (Max: 2MB)</p>
                <div class="image-preview" id="imagePreview">
                    <img id="preview" src="" alt="Image preview">
                </div>
            </div>

            <div class="button-group">
                <button type="submit">Create Blog</button>
                <a href="{{ route('blogs.index') }}" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>

    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('preview').src = e.target.result;
                    document.getElementById('imagePreview').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>