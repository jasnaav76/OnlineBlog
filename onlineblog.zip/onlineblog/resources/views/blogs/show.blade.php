<!DOCTYPE html>
<html>
<head>
    <title>{{ $blog->title }}</title>
</head>
<body>
    <h1>{{ $blog->title }}</h1>
    <p>By: {{ $blog->user->name }} ({{ $blog->user->role }})</p>
    @if($blog->image)
        <img src="{{ asset('uploads/'.$blog->image) }}" width="300"><br><br>
    @endif
    <p>{{ $blog->content }}</p>

    <br>
    <a href="{{ route('blogs.index') }}">Back to Blogs</a>
</body>
</html>
