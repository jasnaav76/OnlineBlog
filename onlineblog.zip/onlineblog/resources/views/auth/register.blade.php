<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Blog Platform</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .register-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            max-width: 900px;
            width: 100%;
            display: grid;
            grid-template-columns: 1fr 1fr;
        }

        .register-image {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            text-align: center;
        }

        .register-image h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            font-weight: 600;
        }

        .register-image p {
            font-size: 1rem;
            line-height: 1.6;
            opacity: 0.9;
        }

        .register-image svg {
            width: 150px;
            height: 150px;
            margin-bottom: 30px;
            opacity: 0.9;
        }

        .register-form {
            padding: 60px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            max-height: 90vh;
            overflow-y: auto;
        }

        .register-form h1 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 10px;
        }

        .register-form .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 0.95rem;
        }

        .alert {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }

        .alert-error {
            background: #fee;
            border: 1px solid #fcc;
            color: #c33;
        }

        .alert-error ul {
            list-style: none;
            padding-left: 0;
        }

        .alert-error li {
            padding: 4px 0;
        }

        .alert-success {
            background: #efe;
            border: 1px solid #cfc;
            color: #3c3;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 500;
            font-size: 0.95rem;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: #f9f9f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .form-group select {
            cursor: pointer;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23333' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 16px center;
            padding-right: 40px;
        }

        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            color: #666;
            font-size: 0.95rem;
        }

        .login-link a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .login-link a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        .view-blogs {
            text-align: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #e0e0e0;
        }

        .view-blogs a {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.95rem;
            transition: color 0.3s ease;
        }

        .view-blogs a:hover {
            color: #764ba2;
        }

        .user-type-info {
            display: flex;
            gap: 10px;
            margin-top: 8px;
            font-size: 0.85rem;
            color: #666;
            background: #f5f5f5;
            padding: 10px;
            border-radius: 6px;
        }

        .user-type-info svg {
            flex-shrink: 0;
            width: 16px;
            height: 16px;
            margin-top: 2px;
        }

        @media (max-width: 768px) {
            .register-container {
                grid-template-columns: 1fr;
            }

            .register-image {
                padding: 40px 30px;
            }

            .register-image svg {
                width: 100px;
                height: 100px;
            }

            .register-form {
                padding: 40px 30px;
            }

            .register-form h1 {
                font-size: 1.75rem;
            }
        }

        @media (max-height: 800px) {
            .register-form {
                padding: 40px;
            }

            .form-group {
                margin-bottom: 16px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-image">
            <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="100" cy="70" r="35" stroke="white" stroke-width="4" fill="none"/>
                <path d="M100 105 Q100 115, 100 115 L100 130" stroke="white" stroke-width="4" stroke-linecap="round"/>
                <path d="M70 130 Q70 120, 100 115 Q130 120, 130 130 L130 160 Q130 170, 120 170 L80 170 Q70 170, 70 160 Z" stroke="white" stroke-width="4" fill="none"/>
                <circle cx="85" cy="65" r="4" fill="white"/>
                <circle cx="115" cy="65" r="4" fill="white"/>
                <path d="M90 80 Q100 85, 110 80" stroke="white" stroke-width="3" stroke-linecap="round" fill="none"/>
            </svg>
            <h2>Join Our Community!</h2>
            <p>Create your account and start sharing your amazing stories and ideas with the world. Connect, inspire, and grow.</p>
        </div>

        <div class="register-form">
            <h1>Register</h1>
            <p class="subtitle">Create your account to get started</p>

            @if ($errors->any())
                <div class="alert alert-error">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
            @endif

            <form action="{{ route('register') }}" method="POST">
                @csrf
                
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" value="{{ old('name') }}" placeholder="Enter your full name" required>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="{{ old('email') }}" placeholder="Enter your email" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Create a strong password" required>
                </div>

                <div class="form-group">
                    <label for="password_confirmation">Confirm Password</label>
                    <input type="password" id="password_confirmation" name="password_confirmation" placeholder="Confirm your password" required>
                </div>

                <div class="form-group">
                    <label for="role">Account Type</label>
                    <select id="role" name="role" required>
                        <option value="USER" {{ old('role')=='USER' ? 'selected' : '' }}>User</option>
                        <option value="ADMIN" {{ old('role')=='ADMIN' ? 'selected' : '' }}>Admin</option>
                    </select>
                    <div class="user-type-info">
                        <svg viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 1a7 7 0 100 14A7 7 0 008 1zm0 13A6 6 0 118 2a6 6 0 010 12zm0-9a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 018 5zm0 8a1 1 0 100-2 1 1 0 000 2z"/>
                        </svg>
                        <span>Choose User for regular access or Admin for full management privileges</span>
                    </div>
                </div>

                <button type="submit" class="submit-btn">Create Account</button>
            </form>

            <div class="login-link">
                Already have an account? <a href="{{ route('login.form') }}">Login here</a>
            </div>

            <div class="view-blogs">
                <a href="{{ route('blogs.index') }}">← View Blog Posts</a>
            </div>
        </div>
    </div>
</body>
</html>